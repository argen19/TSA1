-- Optional: refresh the eight sample dates immediately BEFORE demonstrating.
-- Run only in the dedicated TSA1 demo database; real task dates should not be reset.
-- This updates the supplied sample titles only. It creates or deletes no records.
SET @tsa_today = DATE(DATE_ADD(UTC_TIMESTAMP(), INTERVAL 8 HOUR));
UPDATE tasks SET task_date = DATE_SUB(@tsa_today, INTERVAL 1 DAY)
WHERE title IN ('Review yesterday''s progress', 'Organize the shared project files');
UPDATE tasks SET task_date = @tsa_today
WHERE title IN ('Check the team task schedule', 'Prepare the daily progress report', 'Review and verify pending tasks');
UPDATE tasks SET task_date = DATE_ADD(@tsa_today, INTERVAL 1 DAY)
WHERE title IN ('Plan the next team meeting', 'Update the project documentation', 'Back up the project database');
